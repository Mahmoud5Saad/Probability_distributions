from setuptools import setup

setup(name='basic_dist',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages = ['basic_dist'],
      author = 'Mahmoud Saad',
      author_email = 'mahmoudmsaad@gmail.com',
      zip_safe=False)
